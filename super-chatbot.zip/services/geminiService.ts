import { Message } from '../types';

const WEBHOOK_URL = 'https://Chatclick-n8nfaces.hf.space/webhook-test/11aea888-bc57-4fa9-b25b-2c6c19fdff40';

export const sendMessageToWebhook = async (message: string): Promise<string> => {
  try {
    // Construct URL with message as a query parameter for a GET request
    const url = new URL(WEBHOOK_URL);
    url.searchParams.append('message', message);

    const response = await fetch(url.toString(), {
      method: 'GET',
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Webhook request failed with status ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    
    // Make response handling flexible. Look for common keys.
    if (typeof data.reply === 'string') {
      return data.reply;
    }
    if (typeof data.text === 'string') {
        return data.text;
    }
    if (typeof data.message === 'string') {
        return data.message;
    }
    // Fallback for differently structured JSON or plain text responses from n8n
    if (typeof data === 'string') {
        return data;
    }

    // If no specific key is found, stringify the object to help with debugging.
    return JSON.stringify(data);

  } catch (error) {
    console.error('Error sending message to webhook:', error);
    return 'Sorry, I encountered an error trying to connect to the server.';
  }
};
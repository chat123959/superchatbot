import React from 'react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-end space-x-2 p-4 bg-black/20 rounded-3xl">
      <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
      <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
      <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce"></div>
    </div>
  );
};

export default TypingIndicator;
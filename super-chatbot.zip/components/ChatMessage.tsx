import React from 'react';
import { Message } from '../types';
import ReactMarkdown from 'react-markdown';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === 'user';
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-xl lg:max-w-2xl px-5 py-3 rounded-3xl break-words prose dark:prose-invert text-white shadow-lg ${
          isUser
            ? 'bg-gradient-to-r from-blue-500 to-cyan-500 rounded-br-lg'
            : 'bg-gradient-to-r from-purple-600 to-pink-600 rounded-bl-lg'
        }`}
      >
        <ReactMarkdown>{message.text}</ReactMarkdown>
      </div>
    </div>
  );
};

export default ChatMessage;